package helloworld;

public class HelloWorld { //Must always have a class that has thesame name as the file
    public static void main(String[] args) { // must always have a main function where the code is being ran
        System.out.println("Hello, World!");
    }
}
